import React from 'react';
import Person from './Person/Person'


const persons=(props)=>(props.persons.map((person,index)=>{
  return   <Person id={person.id}
                  name ={person.name}
                  key = {person.id}
                  clicked = {()=>props.clicked(index)}
                  changed ={(event)=>props.changed(event,person.name)}/>

}));

export default persons;
