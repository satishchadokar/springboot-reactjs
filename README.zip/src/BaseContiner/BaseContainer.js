import React, { Component } from 'react'
import { render } from 'react-dom'

const DesableButton=(props)=>(
    <div>
      <div>
        <br/>
        <button onClick={props.disableDropWounHandler}>Disable Dropdown</button>
       
      </div>
      </div>
    );
    
    export default DesableButton;