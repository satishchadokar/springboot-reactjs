import React, { Component } from 'react';

const Person = (props)=> {
return (
      <div className="App">

      <p onClick={props.clicked}>Hi! Person {props.id} and name is {props.name}</p>
        <p >{props.children}</p>
        <input type="text" onChange={props.changed} value={props.name}/>
      </div>
    );

}

export default Person;
