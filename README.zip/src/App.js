  
import logo from './logo.svg';
import './App.css';
import React, { Component } from 'react';
import CustomTab from './Tabs/Tabs';
import DesableButton from './BaseContiner/BaseContainer';
import FatDropdown from  './DataGrid/Dropdowns/Fat';

class App extends Component {
  
  disableDropWounHandler=(event)=>{
    FatDropdown.className = '.Dropdown-disabled';
  }
  
  
  render() {
      return (
      <div className="App">
        <div>
        <CustomTab/>
        <FatDropdown/>
        </div>
        <DesableButton
         disableDropWounHandler = {this.disableDropWounHandler}
        />
        
      </div>
    );
  }
}

export default App;
