import React, { Component } from 'react';
import StyleClasses from './App.css';
import '../componant/Persons/Person/Person.css';
import Persons from '../componant/Persons/Persons';
import Filler from '../componant/smallComponants/smallComponant/smallComponant';


class App extends Component{
    constructor(props){
        super(props);
        this.state = {
          persons:[
              {id : 1 , name : "satish1"},
              {id : 11 , name : "satish11"},
              {id : 111 , name : "satish111"}
          ],
          showPerosn : false

        }
      }

switchNameHandler=()=>{

this.setState({
  persons:[
      {id : 2 , name : "Chadokar"},
      {id : 22 , name : "satish1122"},
      {id : 111 , name : "satish111"}
  ]
})
}

nameChangedHandler=(event,value)=>{

const personIndex = this.state.persons.findIndex(p=>{
  return p.name===value;
});

const changedPerson = {
   ...this.state.persons[personIndex]
 }
 changedPerson.name = event.target.value;
 const newPersons = [...this.state.persons];
 newPersons[personIndex] = changedPerson;

  this.setState({
    persons : newPersons
  })
}


toggleHandler=(event)=>{
  const isShow =  this.state.showPerosn;
  this.setState({showPerosn:!isShow});

}

deletePersonHandler=(personIndex)=>{
  const persons = [...this.state.persons];//this.state.persons;
  persons.splice(personIndex,1);
  this.setState({persons:persons});

}

  render() {
    let persons= null;
    if(this.state.showPerosn){
      persons=(
        <div>
        <Persons
          persons = {this.state.persons}
          clicked = {this.deletePersonHandler}
          changed = {this.nameChangedHandler}
        />
       </div>)
    }
    return (
      <div>
      <Filler
      switchNameHandlerClick = {this.switchNameHandler}
      toggleHandlerClick = {this.toggleHandler}
      />
        {persons}

      </div>

    );
  }
}

export default App;
