import React from 'react';
import StyleClasses from '../../../container/App.css';

const filler=(props)=>(
<div>
  <div className={StyleClasses.App}>
    Hi!<br/>
    <button onClick={props.switchNameHandlerClick}>Switch Name</button>
    <button onClick={props.toggleHandlerClick}>Toggle</button>
  </div>
  </div>
);

export default filler;
